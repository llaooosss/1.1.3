package jm.task.core.jdbc.util;

public class Util {
    // реализуйте настройку соеденения с БД
}
