package jm.task.core.jdbc;

public class Main {
    public static void main(String[] args) {
        // реализуйте алгоритм здесь
    }
}
